import { test, expect } from '@playwright/test';

test('SauceDemo Login Test', async ({ page }) => {
  // Navigate to SauceDemo
  await page.goto('https://www.saucedemo.com/');

  // Enter username and password
  await page.locator('[data-test="username"]').fill('standard_user1');
  await page.locator('[data-test="password"]').fill('secret_sauce');

  // Click Login button
  await page.locator('[data-test="login-button"]').click();

  // Verify successful login
   await expect(page).toHaveURL("https://www.saucedemo.com/inventory.html");
  await expect(page.locator('.title')).toHaveText('Products');
});