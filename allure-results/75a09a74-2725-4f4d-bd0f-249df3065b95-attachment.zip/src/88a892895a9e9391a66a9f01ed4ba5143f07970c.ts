import {test,expect} from '@playwright/test'

test('Monitor API request', async ({ page }) => {
page.on('request', request => { 
        console.log('URL:', request.url()); 
        console.log('Method:', request.method()); 
    });

    await page.goto('https://demoqa.com'); 

});

 //monitor response

test('Monitor API response', async ({ page }) => {

    page.on('response', response => {
        console.log('URL:', response.url());
        console.log('Status:', response.status());
    });

    await page.goto('https://demoqa.com');

});

test.only('Wait for API response', async ({ page }) => {

    const responsePromise = page.waitForResponse(
     response =>                                 
            response.url().includes('demoqa.com') &&
            response.status() === 200
    );
    await page.goto('https://demoqa.com');

    const response = await responsePromise; 
    const resp = await response.json();
    console.log(resp);

    expect(response.ok()).toBeTruthy();
});


