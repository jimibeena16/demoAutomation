import {test, expect} from '@playwright/test'

test('Interact with Expand Testing Shadow DOM using user-facing locators', async ({ page }) => {
  await page.goto('https://practice.expandtesting.com/shadowdom');
 
  const shadowButton = page.getByRole('button', { name: 'This button is inside a Shadow DOM'});
 
  await expect(shadowButton).toBeVisible();
 });

 //Locate Shadow DOM Text Content
test('Verify text inside Shadow DOM', async ({ page }) => {
  await page.goto('https://practice.expandtesting.com/shadowdom');

  const shadowText = page.getByText('This paragraph is inside a Shadow DOM');

  await expect(shadowText).toBeVisible();
});

//Locate Shadow DOM Input by Placeholder
test('Fill input inside Shadow DOM', async ({ page }) => {
  await page.goto('https://practice.expandtesting.com/shadowdom');

  const input = page.getByPlaceholder('Enter text');
  await input.fill('Playwright Shadow DOM');

  await expect(input).toHaveValue('Playwright Shadow DOM');
});

//Locate Shadow DOM Checkbox
test('Check checkbox inside Shadow DOM', async ({ page }) => {
  await page.goto('https://practice.expandtesting.com/shadowdom');

  const checkbox = page.getByRole('checkbox');
  await checkbox.check();

  await expect(checkbox).toBeChecked();
});

//Shadow Host + Child Element
test('Locate element through shadow host', async ({ page }) => {
  await page.goto('https://practice.expandtesting.com/shadowdom');

  const shadowHost = page.locator('#shadow-host');
  const button = shadowHost.locator('button');

  await expect(button).toBeVisible();
});
