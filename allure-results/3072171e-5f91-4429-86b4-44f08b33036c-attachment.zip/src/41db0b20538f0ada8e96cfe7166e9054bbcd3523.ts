import { test, expect } from '@playwright/test';

test('Mouse Hover', async ({ page }) => {
    await page.goto('https://demoqa.com/tool-tips');

    await page.getByRole('button', {name: 'Hover me'}).hover();

    const tooltip = page.getByTestId('tooltip');
    await expect(tooltip).toBeVisible();
    await expect(tooltip).toHaveText('You hovered over the Button');
});

test('Right Click', async ({ page }) => {
    await page.goto('https://demoqa.com/buttons');
    await page.locator('#rightClickBtn').click({button: 'right'});
    await expect(page.locator('#rightClickMessage')).toContainText('You have done a right click');
});

test('Double Click', async ({ page }) => {
    await page.goto('https://demoqa.com/buttons');
    await page.locator('#doubleClickBtn').dblclick();
    await expect(page.locator('#doubleClickMessage')).toContainText('You have done a double click');
});
